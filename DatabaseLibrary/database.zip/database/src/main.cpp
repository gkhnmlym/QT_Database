// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "app_environment.h"
#include "import_qml_components_plugins.h"
#include "import_qml_plugins.h"

#include "databasemanager.h"

int main(int argc, char *argv[])
{
    set_qt_environment();

    QGuiApplication app(argc, argv);

    // Database function
    DatabaseManager database;

    QString machineId = "12";

    if (!database.openDatabase("C:/Users/KEGMULAYIM/Desktop/QT/DATABASE/database.db")) {
        qDebug() << "Exiting due to database open error";
        return -1;
    }

    QMap<QString, QString> tableFields = {
        {"machineId", "INTEGER NOT NULL"},
        {"password", "INTEGER NOT NULL"},
        {"cylinderUp", "INTEGER NOT NULL"},
        {"hopperUp", "INTEGER NOT NULL"},
        {"cylinderSet", "INTEGER NOT NULL"},
        {"hopperSet", "INTEGER NOT NULL"},
        {"pressureLow", "REAL NOT NULL"},
        {"pressure", "REAL NOT NULL"},
        {"pressureLowSelf", "REAL NOT NULL"},
        {"pressureHighSelf", "REAL NOT NULL"},
        {"pressureFluidSelf", "REAL NOT NULL"},
        {"pressureFluid", "REAL NOT NULL"},
        {"iceCreamHardness", "REAL NOT NULL"},
        {"iceCreamCount", "INTEGER NOT NULL"},
        {"washDay", "INTEGER NOT NULL"}
    };

    if (!database.createTable("testtable", tableFields)) {
        qDebug() << "Exiting due to table creation error";
        return -1;
    }

    QMap<QString, QVariant> insertValues = {
        {"machineId", machineId},
        {"password", 56},
        {"cylinderUp", 46},
        {"hopperUp", 96},
        {"cylinderSet", 96},
        {"hopperSet", 46},
        {"pressureLow", 46.0},
        {"pressure", 46.0},
        {"pressureLowSelf", 56.0},
        {"pressureHighSelf", 56.0},
        {"pressureFluidSelf", 96.0},
        {"pressureFluid", 56.0},
        {"iceCreamHardness", 56.0},
        {"iceCreamCount", 96},
        {"washDay", 46}
    };

    QMap<QString, QVariant> updateValues = {
        {"password", 56},
        {"cylinderUp", 24},
        {"hopperUp", 26},
        {"cylinderSet", 96},
        {"hopperSet", 46},
        {"pressureLow", 46.0},
        {"pressure", 46.0},
        {"pressureLowSelf", 56.0},
        {"pressureHighSelf", 56.0},
        {"pressureFluidSelf", 96.0},
        {"pressureFluid", 56.0},
        {"iceCreamHardness", 56.0},
        {"iceCreamCount", 96},
        {"washDay", 46}
    };

    if (!database.addValues("testtable", insertValues)) {
        qDebug() << "Exiting due to error adding values";
        return -1;
    }

    if (database.updateValues("testtable", updateValues, "machineId = '" + machineId + "'")) {
        qDebug() << "Values updated successfully.";
    } else {
        qDebug() << "Error updating values.";
    }

    database.closeDatabase();

    qDebug() << "End";


    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:Main/main.qml"_qs);
    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreated, &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);

    engine.addImportPath(QCoreApplication::applicationDirPath() + "/qml");
    engine.addImportPath(":/");

    engine.load(url);

    if (engine.rootObjects().isEmpty()) {
        return -1;
    }

    return app.exec();
}
